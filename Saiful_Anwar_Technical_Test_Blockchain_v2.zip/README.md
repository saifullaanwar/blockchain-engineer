# Technical Test — Junior Blockchain Engineer @ Dattabot

> Solusi untuk 4 soal teknis: JavaScript dasar, REST API, integrasi API eksternal dengan cache, dan smart contract Solidity di blockchain testnet.

**Author:** Saiful Anwar
**Date completed:** May 16, 2026
**Status:** ✅ 4 modul selesai • 128 test passing • Smart contract live di Sepolia

---

## Isi Repository

Repository ini berisi 4 folder, satu folder per soal. Tiap folder berdiri sendiri (punya `package.json`, `node_modules/`, test, dan README masing-masing) — bisa di-install, di-test, dan dijalankan tanpa saling mengganggu.

| # | Folder | Yang dikerjakan | Test |
|---|---|---|---|
| 1 | [`1_print_dattabot/`](./1_print_dattabot/) | Function print angka 1..n dengan substitusi prime/fibonacci, plus CLI | **65 PASS** |
| 2 | [`2_array_diff_function/`](./2_array_diff_function/) | Fungsi diff dua array (handle duplikat) + REST API endpoint | **26 PASS** |
| 3 | [`3_crypto_to_idr_converter/`](./3_crypto_to_idr_converter/) | Konversi crypto ke IDR via 2 public API + cache 60 detik, dengan CLI + HTML + REST API | **30 PASS** |
| 4 | [`4_bereitstellen/`](./4_bereitstellen/) | Smart contract Solidity di-deploy ke Sepolia testnet, dengan deploy & interact script | **7 PASS** |

**Total: 128 test passing.**

---

## Bukti Smart Contract Live di Blockchain (Modul 4)

Smart contract `Bereitstellen` **sudah beneran ter-deploy** di Sepolia testnet — bukan simulasi lokal. Siapa pun bisa verifikasi langsung di Etherscan tanpa perlu install apa-apa:

| Field | Value |
|---|---|
| **Contract Address** | [`0x1e2b21C2b91aBa82E54EA1094CAa31DAB4a30D81`](https://sepolia.etherscan.io/address/0x1e2b21C2b91aBa82E54EA1094CAa31DAB4a30D81) |
| **Network** | Sepolia Testnet (Chain ID `11155111`) |
| **Wallet Deployer** | [`0xfAc1A1e027ADAcEAfDbB7dE745045C04Edc63FEE`](https://sepolia.etherscan.io/address/0xfAc1A1e027ADAcEAfDbB7dE745045C04Edc63FEE) |
| **Transaksi Deploy** | [`0xded9c6bc...c302ffd607`](https://sepolia.etherscan.io/tx/0xded9c6bc9d629ead8ddd523c4db727d886680456393e5b8bc5ee84c302ffd607) |
| **Transaksi `setColor("blue")`** | [`0x350b5242...994732b9`](https://sepolia.etherscan.io/tx/0x350b5242d0303c6c6de83b415176924c75ed8326e30465a5f858e538994732b9) |

Klik link mana saja → buka di Etherscan → bisa lihat contract code, transaksi confirmed, dan method yang dipanggil.

---

## Persiapan (Sekali Saja)

### 1. Install Node.js 18+

Download dari https://nodejs.org. Verifikasi versi:

```powershell
node --version    # harus v18 atau lebih baru
npm --version
```

### 2. Khusus Windows + PowerShell — set execution policy

Default Windows PowerShell **menolak** menjalankan script `.ps1` (termasuk `npm`). Set sekali, semua modul bisa langsung jalan:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

Tutup terminal, buka terminal baru. Verifikasi:

```powershell
Get-ExecutionPolicy -Scope CurrentUser    # harus output: RemoteSigned
```

> Setting ini aman: script lokal (yang kamu/installer bikin) boleh jalan, script dari internet harus signed. Tidak perlu Admin (scope `CurrentUser`). Alternatif tanpa ubah policy: pakai `npm.cmd` (bukan `npm`) di tiap command.

### 3. (Opsional, hanya untuk deploy ulang Modul 4)

- MetaMask test wallet (bukan akun yang punya ETH mainnet — gunakan wallet test terpisah)
- API key Alchemy untuk Sepolia (https://alchemy.com, gratis)
- Sepolia ETH dari faucet (https://sepoliafaucet.com)

**Tidak perlu** kalau cuma mau verifikasi contract yang sudah ter-deploy lewat Etherscan.

---

## Cara Menjalankan & Test Tiap Modul

Asumsi posisi awal terminal: di root repo (`technical-test-blockchain`).

### Modul 1 — Print Dattabot (1 terminal)

Function yang print angka 1..n, dengan substitusi:
- prime → `"datta"`
- fibonacci → `"bot"`
- prime **dan** fibonacci → `"dattabot"`
- selain itu → angka itu sendiri

**Langkah 1 — Setup & jalankan automated test:**

```powershell
cd 1_print_dattabot
npm install
npm test
```

Harus output **65 tests passing**.

**Langkah 2 — Manual run untuk `n=15`:**

```powershell
node 1_print_dattabot.js 15
```

Expected output:
```
[1,"dattabot","dattabot",4,"dattabot",6,"datta","bot",9,10,"datta",12,"dattabot",14,15]
```

**Langkah 3 — Coba `n` lain dan input invalid** (semua input invalid harus error dengan exit code 1):

```powershell
node 1_print_dattabot.js 30          # ok
node 1_print_dattabot.js 50          # ok
node 1_print_dattabot.js abc         # error: not a positive integer
node 1_print_dattabot.js -5          # error: not a positive integer
node 1_print_dattabot.js             # error: missing argument
```

> **Catatan:** output `n=15` **tidak match** dengan contoh di soal PDF. Itu karena contoh PDF inkonsisten dengan rules-nya sendiri (8 dari 15 posisi salah — misal angka 5 yang prime+fibonacci di PDF tampil `"datta"`, padahal rules bilang harusnya `"dattabot"`). Implementasi mengikuti rules; detail penjelasan di [1_print_dattabot/README.md](./1_print_dattabot/README.md).

---

### Modul 2 — Array Diff REST API (2 terminal)

Function & REST endpoint yang return elemen yang ada di satu array saja (tidak di keduanya). Dua implementasi: V1 (`Array.includes`, O(n·m)) dan V2 (`Set.has`, O(n+m)) — hasil identik.

**Langkah 1 — Setup & jalankan automated test:**

```powershell
cd ..\2_array_diff_function
npm install
npm test
```

Harus output **26 tests passing**.

**Langkah 2 — Start server (terminal 1, jangan ditutup):**

```powershell
npm start
```

Tunggu muncul log: `array-diff server listening on http://localhost:3000`.

**Langkah 3 — Buka terminal kedua** di VS Code (klik icon `+` di panel terminal, atau tekan `` Ctrl+Shift+` ``).

**Langkah 4 — Kirim request dari terminal kedua** pakai contoh dari soal PDF (`[1,3,5,7,9]` ∆ `[1,2,3,4]`):

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:3000/array-diff -ContentType "application/json" -Body '{"a":[1,3,5,7,9],"b":[1,2,3,4]}' | ConvertTo-Json
```

Expected output:
```json
{
  "result": [2, 4, 5, 7, 9],
  "version": "v2",
  "timeMs": 0.43
}
```

> **⚠️ Gotcha PowerShell:** kalau **tanpa** `| ConvertTo-Json`, output table-nya akan tampak truncate `{2, 4, 5, 7...}` dengan tanda `...`. Itu **bukan data hilang** — cuma `Format-Table` PowerShell yang motong cell panjang. Selalu pipe `| ConvertTo-Json` biar lihat hasil lengkap.

**Langkah 5 — Test case tambahan:**

```powershell
# Duplikat: [1,1,2] vs [1,3] → expect result = [2,3]
Invoke-RestMethod -Method Post -Uri http://localhost:3000/array-diff -ContentType "application/json" -Body '{"a":[1,1,2],"b":[1,3]}' | ConvertTo-Json

# Semua overlap → expect result = []
Invoke-RestMethod -Method Post -Uri http://localhost:3000/array-diff -ContentType "application/json" -Body '{"a":[1,2,3],"b":[3,2,1]}' | ConvertTo-Json

# Force versi V1 (algoritma O(n*m), hasil identik dengan V2)
Invoke-RestMethod -Method Post -Uri http://localhost:3000/array-diff -ContentType "application/json" -Body '{"a":[1,3,5,7,9],"b":[1,2,3,4],"version":"v1"}' | ConvertTo-Json

# Error path: "a" bukan array → expect HTTP 400
try {
  Invoke-RestMethod -Method Post -Uri http://localhost:3000/array-diff -ContentType "application/json" -Body '{"a":"bukan-array","b":[1,2]}'
} catch {
  $_.ErrorDetails.Message
}
```

**Langkah 6 — Stop server** di terminal 1: tekan `Ctrl+C`.

---

### Modul 3 — Crypto to IDR Converter (3 mode pakai)

Konversi nilai crypto (BTC/ETH/DOGE/BNB/SOL) ke Rupiah lewat 2 public API gratis (CoinGecko + open.er-api). Cache 60 detik untuk hemat quota & latency.

**Setup & jalankan automated test** (semua API call di-mock pakai nock, jadi **tidak perlu internet** untuk `npm test`):

```powershell
cd ..\3_crypto_to_idr_converter
npm install
npm test
```

Harus output **30 tests passing**.

Modul ini bisa dipakai 3 cara — pilih sesuai kebutuhan:

#### Mode A — CLI (1 terminal, butuh internet)

```powershell
npm run cli -- --symbol BTC --amount 1
```

> Tanda `--` setelah `cli` **wajib** — biar npm gak menelan flag `--symbol`-nya.

Expected output (angka pasti beda karena harga BTC real-time):
```json
{"crypto":"BTC","amount":1,"idr":1370831678}
```

Coba symbol lain:
```powershell
npm run cli -- --symbol ETH  --amount 0.5
npm run cli -- --symbol DOGE --amount 100
npm run cli -- --symbol SOL  --amount 2.5
npm run cli -- --symbol BNB  --amount 1

# Error: symbol tidak supported
npm run cli -- --symbol XYZ  --amount 1
# → {"error":"Unsupported crypto symbol: \"XYZ\". Supported: BTC, ETH, DOGE, BNB, SOL"}

# Error: amount invalid
npm run cli -- --symbol BTC  --amount -5
# → {"error":"amount must be a non-negative finite number"}
```

#### Mode B — HTML Web UI (server + browser)

**Terminal 1 — start server:**

```powershell
npm start
```

Tunggu log: `crypto-to-idr server on http://localhost:3001`.

**Buka browser ke http://localhost:3001** — bukan double-click file HTML. (HTML pakai `fetch('/symbols')` dan `fetch('/convert')` yang cuma works kalau di-serve oleh server.)

Dropdown akan auto-load 5 symbol. Pilih, isi amount, klik **Convert**. Hasil tampil dengan format Indonesia, misalnya `1 BTC = Rp 1.387.506.256`.

#### Mode C — HTTP API (server + Invoke-RestMethod)

Server sudah jalan dari Mode B. Di terminal kedua:

```powershell
# GET list symbol
Invoke-RestMethod -Uri http://localhost:3001/symbols | ConvertTo-Json

# POST convert
Invoke-RestMethod -Method Post -Uri http://localhost:3001/convert -ContentType "application/json" -Body '{"symbol":"BTC","amount":1}' | ConvertTo-Json
```

**Demo caching** — panggil 2 kali, call kedua jauh lebih cepat (cache hit, TTL 60 detik):

```powershell
Measure-Command { Invoke-RestMethod -Method Post -Uri http://localhost:3001/convert -ContentType "application/json" -Body '{"symbol":"BTC","amount":1}' }
Measure-Command { Invoke-RestMethod -Method Post -Uri http://localhost:3001/convert -ContentType "application/json" -Body '{"symbol":"BTC","amount":2}' }
```

Call pertama: ~1000ms (network round-trip ke CoinGecko + exchange API). Call kedua: ~30ms (cache hit, **~33× lebih cepat**).

**Stop server:** tekan `Ctrl+C` di terminal 1.

---

### Modul 4 — Smart Contract Bereitstellen

Smart contract Solidity dengan `onlyDeployer` modifier — hanya wallet yang deploy contract yang bisa update warna. Kalau wallet lain coba `setColor`, contract akan **revert** dengan pesan `"Can only be called by deployer"`.

**Langkah 1 — Setup & jalankan automated test** (offline, pakai in-memory Hardhat network, **tidak perlu internet**):

```powershell
cd ..\4_bereitstellen
npm install
npm test
```

Harus output **7 passing** dengan semua requirement ter-cover:
- ✓ default color is `"white"`
- ✓ deployer stored correctly
- ✓ deployer can call setColor and state updates
- ✓ non-deployer cannot call setColor — reverts with exact message
- ✓ constructor emits `ColorChanged(deployer, "white")`
- ✓ setColor emits `ColorChanged` with correct args
- ✓ setColor with empty string is allowed by design

#### Verifikasi contract live di blockchain (cara gampang — buka browser saja)

Contract sudah ter-deploy. Buka URL berikut di browser:

- **Contract:** https://sepolia.etherscan.io/address/0x1e2b21C2b91aBa82E54EA1094CAa31DAB4a30D81
- **Transaksi deploy:** https://sepolia.etherscan.io/tx/0xded9c6bc9d629ead8ddd523c4db727d886680456393e5b8bc5ee84c302ffd607
- **Transaksi `setColor("blue")`:** https://sepolia.etherscan.io/tx/0x350b5242d0303c6c6de83b415176924c75ed8326e30465a5f858e538994732b9

Di Etherscan akan terlihat: contract address valid, 2 transaksi confirmed, method `setColor` ter-decode otomatis ke `blue`, gas usage 31,428.

#### (Opsional) Deploy ulang sendiri ke Sepolia

Butuh Alchemy API key + Sepolia ETH (lihat **Persiapan → poin 3** di atas).

```powershell
# Setup credentials sekali
copy .env.example .env
# Edit .env: isi ALCHEMY_URL dan PRIVATE_KEY

# Deploy
npm run deploy:sepolia

# Interact: panggil setColor + verifikasi revert dari random wallet
npm run interact:sepolia
```

Detail lengkap di [4_bereitstellen/README.md](./4_bereitstellen/README.md).

---

## Struktur Folder

```
technical-test-blockchain/
├── .gitignore                            # .env, node_modules, cache/, artifacts/
├── README.md                             # file ini
│
├── 1_print_dattabot/                     # 65 tests
│   ├── 1_print_dattabot.js               # main + CLI entry
│   ├── dattabot.test.js                  # 55 unit tests
│   ├── cli.test.js                       # 10 CLI tests (spawnSync)
│   └── README.md
│
├── 2_array_diff_function/                # 26 tests
│   ├── 2_array_diff_function.js          # diffV1 (O(n·m)), diffV2 (O(n+m))
│   ├── server.js                         # Express factory
│   ├── diff.test.js                      # 19 unit + parity fuzz
│   ├── server.test.js                    # 7 supertest endpoint
│   └── README.md
│
├── 3_crypto_to_idr_converter/            # 30 tests
│   ├── cache.js                          # TTLCache (60s default)
│   ├── converter.js                      # fetch + convert + typed errors
│   ├── 3_crypto_to_idr_converter.js      # CLI (yargs)
│   ├── server.js                         # Express factory
│   ├── public/index.html                 # HTML interface
│   ├── cache.test.js                     # 6 tests
│   ├── converter.test.js                 # 18 nock-mocked
│   ├── server.test.js                    # 6 supertest
│   ├── .env.example
│   └── README.md
│
└── 4_bereitstellen/                      # 7 tests + live di Sepolia
    ├── contracts/Bereitstellen.sol       # Solidity 0.8.30
    ├── scripts/deploy.js                 # ethers v6
    ├── scripts/interact.js               # setColor + staticCall revert verify
    ├── test/bereitstellen.test.js        # 7 tests
    ├── hardhat.config.js                 # solc 0.8.30 + conditional sepolia
    ├── deployment.json                   # snapshot tx hashes + addresses
    ├── .env.example
    └── README.md
```

---

## Catatan Penting (Engineering Decisions)

Beberapa keputusan teknis yang sengaja menyimpang dari spek atau worth flagging — semua sudah didokumentasi transparan di README modul masing-masing:

1. **Modul 1 — output beda dengan contoh PDF.** Contoh output di soal inkonsisten dengan rules tertulis-nya sendiri (8 dari 15 posisi salah). Implementasi mengikuti rules.
2. **Modul 3 — pakai CoinGecko, bukan CoinDesk.** CoinDesk hanya support BTC; soal minta multi-crypto. CoinGecko free tier cover semua 5 symbol tanpa API key.
3. **Modul 4 — `string calldata`, bukan `memory`.** Hemat ~5% gas per call. Soal asli pakai `memory`, deviasi dijelaskan di kode + README.
4. **Fail-loud principle** — invalid input fail dengan error message + exit code 1. Bug modul 1 CLI yang silent fallback ke n=15 ditemukan via manual testing, di-fix + 10 regression tests.
5. **Cache exposed sebagai `_cache`** di Modul 3 untuk testability (`_cache.clear()` di `beforeEach`), tanpa over-engineering factory pattern.

---

## Submission Checklist

| Check | Status |
|---|---|
| 4 modul selesai | ✅ |
| Semua test passing | ✅ 128/128 |
| Modul 4 contract live di Sepolia | ✅ `0x1e2b21C2...` |
| Etherscan verifiable (contract + 2 tx) | ✅ 3 link public |
| `.env` tidak ter-commit | ✅ verified via `git log -- '**/.env'` (zero results) |
| `.gitignore` cover `node_modules`, `.env`, `cache/`, `artifacts/` | ✅ |
| README per modul + README root | ✅ 5 README |
| Deviasi spek didokumentasi transparan | ✅ modul 1, 3, 4 |
| Bug fix notes | ✅ modul 1 CLI |

---

**Ready for review.**
