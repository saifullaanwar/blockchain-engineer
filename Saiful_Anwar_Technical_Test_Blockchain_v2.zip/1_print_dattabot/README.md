# 1 — Print Dattabot

Function `printDattabot(n)` mengembalikan array `1..n` dengan substitusi berdasarkan sifat angka:

| Kondisi | Output |
|---|---|
| `n == 1` | `1` (special case) |
| prime **dan** fibonacci | `"dattabot"` |
| prime saja | `"datta"` |
| fibonacci saja | `"bot"` |
| selain itu | angka itu sendiri |

## How to Run

### CLI Mode

```sh
node 1_print_dattabot.js <n>
```

Where `n` is a positive integer >= 1.

**Examples:**

```sh
node 1_print_dattabot.js 15    # Returns array for n=15
node 1_print_dattabot.js 1     # Returns [1] (special case)
node 1_print_dattabot.js 50    # Returns array for n=50
```

**Error handling:** Invalid input (negative, zero, float, non-numeric, or missing) will print error to stderr and exit with code 1.

```sh
node 1_print_dattabot.js          # Error: missing argument
node 1_print_dattabot.js abc      # Error: not a positive integer
node 1_print_dattabot.js -5       # Error: not a positive integer
node 1_print_dattabot.js 1.5      # Error: not a positive integer
```

### Programmatic Usage

```js
const { printDattabot, isPrime, isFibonacci } = require('./1_print_dattabot');

const result = printDattabot(15);
// [1, "dattabot", "dattabot", 4, "dattabot", 6, "datta", "bot",
//  9, 10, "datta", 12, "dattabot", 14, 15]
```

## Testing

```sh
npm install
npm test
```

Test suite includes **65 tests across 2 files**:

- `dattabot.test.js` (55 tests) — `isPrime`, `isFibonacci`, `printDattabot` core logic
- `cli.test.js` (10 tests) — CLI argument parsing and validation via `spawnSync` subprocess

## Implementasi

- `isPrime(n)` — trial division 2 + odd-only sampai `√n`. **O(√n)**.
- `isFibonacci(n)` — perfect square check: `n` fibonacci iff `5n²+4` atau `5n²−4` perfect square (identitas Binet). **O(1)**.
- `printDattabot(n)` — loop sekali dari 1..n, tiap iterasi panggil kedua helper.

**Total time complexity: O(n · √n)** — didominasi oleh `isPrime`.
Space: O(n) untuk array output.

## Catatan Implementasi

Saya menemukan inkonsistensi antara rules tertulis di soal dan expected output yang diberikan:

- Rules tertulis: prime → "datta", fibonacci → "bot", keduanya → "dattabot"
- Expected output di soal mengandung beberapa kasus yang TIDAK konsisten dengan rules tersebut. Contoh: angka 5 dan 13 adalah prime DAN fibonacci, tapi di expected output PDF muncul sebagai "datta", bukan "dattabot".

Saya memilih untuk mengikuti **rules tertulis** karena:

1. Rules yang konsisten secara matematis dapat dipertanggungjawabkan saat technical interview
2. Helper functions (isPrime, isFibonacci) reusable dan dapat diuji secara independen
3. Implementasi mudah di-extend untuk n yang lebih besar tanpa perlu hardcode pattern

Jika rekruter menginginkan output persis match dengan contoh di PDF soal, saya bersedia menyesuaikan implementasi sesuai pattern yang diinginkan setelah mendapat klarifikasi.

### Output Implementasi vs Output PDF (n=15)

**Implementasi saya (rules prime/fibonacci murni):**

```
[1, "dattabot", "dattabot", 4, "dattabot", 6, "datta", "bot", 9, 10,
 "datta", 12, "dattabot", 14, 15]
```

**PDF soal:**

```
[1, "dattabot", "dattabot", 4, "datta", "bot", "datta", 8, "datta", "bot",
 "datta", 12, "datta", "bot", "datta"]
```

Perbedaan utama ada di angka yang merupakan prime DAN fibonacci (5, 13) dan angka fibonacci murni (8).

## Bug Fix Notes

### CLI Argument Parsing (fixed in commit b296239)

**Issue:** Original CLI entry point had silent fallback to `n=15` for any invalid input (NaN, negative, zero, float, missing). This anti-pattern hides bugs from users instead of failing loud.

**Root cause:**

```js
const n = Number.isInteger(arg) && arg > 0 ? arg : 15;  // bug: fallback to 15
```

**Fix:**

- Separated "missing argument" vs "invalid argument" with distinct error messages
- Errors written to `stderr` (not `stdout`) with `process.exit(1)`
- Output format changed to `JSON.stringify(...)` for valid JSON output (double-quoted strings) per requirement

**Test coverage:** 10 new tests in `cli.test.js` using `spawnSync` to spawn the CLI as subprocess and verify both happy path and error exit codes. This prevents regression of this bug class.
