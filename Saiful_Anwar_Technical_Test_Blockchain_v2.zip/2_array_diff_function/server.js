'use strict';

const express = require('express');
const { diffV1, diffV2 } = require('./2_array_diff_function');

function createApp() {
  const app = express();
  app.use(express.json());

  app.post('/array-diff', (req, res) => {
    const { a, b, version } = req.body || {};

    if (!Array.isArray(a) || !Array.isArray(b)) {
      return res.status(400).json({ error: 'Both a and b must be arrays' });
    }
    const v = version ?? 'v2';
    if (v !== 'v1' && v !== 'v2') {
      return res.status(400).json({ error: 'version must be "v1" or "v2"' });
    }

    const fn = v === 'v1' ? diffV1 : diffV2;
    const start = process.hrtime.bigint();
    const result = fn(a, b);
    const timeMs = Number(process.hrtime.bigint() - start) / 1e6;

    return res.json({ result, version: v, timeMs });
  });

  // JSON parse error handler — must come after routes
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err && err.type === 'entity.parse.failed') {
      return res.status(400).json({ error: 'Invalid JSON body' });
    }
    return res.status(500).json({ error: 'Internal error' });
  });

  return app;
}

module.exports = { createApp };

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  createApp().listen(port, () => {
    console.log(`array-diff server listening on http://localhost:${port}`);
  });
}
