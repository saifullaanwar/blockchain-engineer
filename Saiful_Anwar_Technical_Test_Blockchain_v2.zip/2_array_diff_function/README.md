# 2 — Array Diff Function + REST API

Symmetric difference dengan aturan: **kalau sebuah value muncul di kedua array, buang seluruhnya** (termasuk duplikat).

| `a` | `b` | Output |
|---|---|---|
| `[1,3,5,7,9]` | `[1,2,3,4]` | `[2,4,5,7,9]` |
| `[1,1,2]` | `[1,3]` | `[2,3]` |
| `[1,2,3]` | `[3,2,1]` | `[]` |
| `[]` | `[1,2,2,3]` | `[1,2,3]` |

## Run

```sh
npm install
npm test           # Jest + supertest — 26 tests (19 unit + 7 endpoint)
npm start          # server di :3000 (override via env PORT)
```

Manual:

```sh
curl -X POST http://localhost:3000/array-diff \
  -H "Content-Type: application/json" \
  -d "{\"a\":[1,3,5,7,9],\"b\":[1,2,3,4]}"
# → {"result":[2,4,5,7,9],"version":"v2","timeMs":0.12}
```

## API

`POST /array-diff`

Request body:

```json
{ "a": [...], "b": [...], "version": "v1" | "v2" }
```

`version` opsional, default `v2`.

Response 200:

```json
{ "result": [...], "version": "v2", "timeMs": 0.12 }
```

Response 400 (`a`/`b` bukan array, `version` invalid, JSON parse error):

```json
{ "error": "Both a and b must be arrays" }
```

## Two Implementations

| | Lookup | Complexity | Catatan |
|---|---|---|---|
| `diffV1` | `Array.includes` | **O(n · m)** | Baseline naive, readable |
| `diffV2` | `Set.has` | **O(n + m)** | Optimal untuk array besar |

Output keduanya identik — diverifikasi via fuzz parity test (20 random case per run).

## Design Decisions

**1. Ordering: sorted ascending.**

Hasil di-sort pakai comparator universal `(a, b) => a < b ? -1 : a > b ? 1 : 0` (works untuk number maupun string). Alasan:

- **Deterministik** — sama input selalu kasih sama output. Tidak bergantung urutan internal `Set` iteration.
- **Match contoh soal** — `[2,4,5,7,9]` adalah sorted ascending.
- **Set semantics** — symmetric difference matematis adalah operasi pada SET, dan set tidak punya order. Sorting adalah normalisasi natural.

Alternatif yang ditolak: preserve original order (a's remainder lalu b's remainder). Tidak deterministik untuk kasus seperti `[5,3,1]` vs `[4,2]`, dan tidak match contoh soal.

**2. Duplikat di-dedupe seluruhnya.**

Kasus `[1,1,2]` vs `[1,3]` → `[2,3]` (bukan `[2,2,3]`). Interpretasi: `1` muncul di kedua array → buang semua `1`; sisa `[2]` ∪ `[3]` → dedupe → `[2,3]`.

Implementasi pakai `Set`, bukan multiset/Map counter — karena soal bilang "buang seluruhnya kalau value ada di kedua array".

**3. V1 vs V2 dipertahankan dua-duanya.**

V1 sengaja tetap pakai `includes` walau O(n·m) — untuk demonstrasi trade-off Set vs linear scan di interview. Parity test memastikan optimasi V2 tidak mengubah behavior.

**4. Validasi defensif di endpoint.**

400 dengan pesan jelas untuk: `a`/`b` bukan array, `version` invalid (`!== "v1" | "v2"`), JSON parse error. Tidak melempar 500 untuk input yang user-fixable.

**5. `createApp()` factory + `require.main` guard.**

Server di-export sebagai factory tanpa side-effect — supertest bisa import `createApp()` tanpa benar-benar `listen()` ke port. `app.listen()` hanya dijalankan kalau file di-execute langsung (`node server.js`). Pattern standar Express untuk testability.

**6. `timeMs` di response.**

Pakai `process.hrtime.bigint()` untuk timing precision sub-millisecond. Useful untuk verifikasi visual perbedaan V1 vs V2 pada array besar. Tidak diukur di test (timing flaky di CI), tapi handy untuk demo manual via curl.
