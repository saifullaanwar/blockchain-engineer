'use strict';

const request = require('supertest');
const { createApp } = require('./server');

const app = createApp();

describe('POST /array-diff', () => {
  test('200 default v2: [1,3,5,7,9] vs [1,2,3,4]', async () => {
    const res = await request(app)
      .post('/array-diff')
      .send({ a: [1, 3, 5, 7, 9], b: [1, 2, 3, 4] });
    expect(res.status).toBe(200);
    expect(res.body.result).toEqual([2, 4, 5, 7, 9]);
    expect(res.body.version).toBe('v2');
    expect(typeof res.body.timeMs).toBe('number');
  });

  test('200 explicit v1', async () => {
    const res = await request(app)
      .post('/array-diff')
      .send({ a: [1, 1, 2], b: [1, 3], version: 'v1' });
    expect(res.status).toBe(200);
    expect(res.body.result).toEqual([2, 3]);
    expect(res.body.version).toBe('v1');
  });

  test('400 a bukan array', async () => {
    const res = await request(app)
      .post('/array-diff')
      .send({ a: 'foo', b: [1, 2] });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/array/i);
  });

  test('400 b bukan array', async () => {
    const res = await request(app)
      .post('/array-diff')
      .send({ a: [1, 2], b: 42 });
    expect(res.status).toBe(400);
  });

  test('400 body kosong', async () => {
    const res = await request(app).post('/array-diff').send({});
    expect(res.status).toBe(400);
  });

  test('400 version invalid', async () => {
    const res = await request(app)
      .post('/array-diff')
      .send({ a: [1], b: [2], version: 'v3' });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/version/i);
  });

  test('400 body bukan JSON valid', async () => {
    const res = await request(app)
      .post('/array-diff')
      .set('Content-Type', 'application/json')
      .send('{broken');
    expect(res.status).toBe(400);
  });
});
