# 3 — Crypto to IDR Converter

CLI + HTTP service yang konversi `amount × harga_crypto_USD × USD/IDR_rate` jadi IDR. Pakai dua public API gratis (tanpa API key) dengan caching in-memory.

## Running the App

```sh
cp .env.example .env       # opsional, semua punya default
npm install
npm test                   # unit + integration (semua mocked, no network)
```

### Mode 1: HTML Interface (recommended for demo)

```sh
npm start
```

Server listen di `http://localhost:3001`. Buka di browser — dropdown auto-load symbol dari `GET /symbols`, isi amount, klik **Convert**. Hasil di-render dengan format Indonesia (mis. `1 BTC = Rp 1.387.506.256`) via `Intl.NumberFormat('id-ID')`.

> **Catatan:** HTML harus diakses via `http://localhost:3001` (bukan `file://`). HTML melakukan `fetch('/symbols')` dan `fetch('/convert')` — same-origin request yang hanya valid kalau dokumen di-serve oleh server yang sama.

### Mode 2: CLI Converter

```sh
npm run cli -- --symbol BTC --amount 1
# atau short: node 3_crypto_to_idr_converter.js -s ETH -a 0.5
```

Output:

```json
{"crypto":"BTC","amount":1,"idr":1386894650}
```

Flag `--` di `npm run cli --` penting — tanpa itu, npm yang ambil argumen, bukan script-nya.

### Mode 3: HTTP API (untuk integrasi programatik)

Start server (sama seperti Mode 1):

```sh
npm start
```

Lalu POST request ke `/convert`:

```sh
curl -X POST http://localhost:3001/convert \
  -H "Content-Type: application/json" \
  -d "{\"symbol\":\"BTC\",\"amount\":1}"
```

Response 200:

```json
{"crypto":"BTC","amount":1,"idr":1386894650}
```

Endpoint lain: `GET /symbols` → `{"symbols":["BTC","ETH","DOGE","BNB","SOL"]}`.

## API

`POST /convert` body `{ "symbol": "BTC", "amount": 1 }` → `200 { crypto, amount, idr }`
`GET /symbols` → `{ symbols: ["BTC", "ETH", ...] }`

Error codes:
- `400` — input invalid (unsupported symbol, amount bukan number non-negative, JSON parse error)
- `502` — upstream API down / response invalid

## Supported Symbols

`BTC`, `ETH`, `DOGE`, `BNB`, `SOL` — di-mapping internal ke CoinGecko id (`bitcoin`, `ethereum`, `dogecoin`, `binancecoin`, `solana`).

## Architecture

```
┌─────────────────────┐         ┌──────────────┐
│ 3_..._converter.js  │ ──┐     │              │
│ (CLI, yargs)        │   │     │  CoinGecko   │
└─────────────────────┘   ├──→ converter.js ──→  open.er-api │
┌─────────────────────┐   │     │              │
│ server.js + HTML    │ ──┘     └──────────────┘
└─────────────────────┘              ↑↓
                                 ┌────────┐
                                 │  TTL   │  in-memory cache
                                 │ Cache  │  (60s default)
                                 └────────┘
```

## Why CoinGecko, not CoinDesk

Soal menyebut CoinDesk sebagai **contoh** sumber data, bukan requirement teknis. Beberapa pertimbangan kenapa saya pilih CoinGecko:

1. **Cakupan symbol.** CoinDesk Bitcoin Price Index hanya support BTC. Soal mensyaratkan multi-crypto (BTC, ETH, DOGE, BNB, SOL) — CoinDesk tidak bisa dipakai tanpa kombinasi dengan provider kedua untuk altcoin.
2. **CoinGecko free tier:** ~10,000+ coin, ~50 req/menit, tanpa API key. Cukup untuk demo & development.
3. **Format response konsisten.** Endpoint `simple/price?ids=...&vs_currencies=usd` mengembalikan struktur yang seragam untuk semua coin.
4. **Abstraksi tetap memungkinkan switch.** URL provider dibaca dari `process.env.COINGECKO_API_URL` — kalau besok mau ganti ke Binance / CoinDesk / aggregator lain, cukup ubah env var + adapter `fetchCryptoUsd` (selama response shape kompatibel). Tidak perlu refactor caller.

## Design Decisions

**1. Cache: singleton module-level `TTLCache`.**

Cache di-instantiate sekali di `converter.js` load time, di-share antara semua caller (CLI dan server). Lebih simple dari factory yang di-pass ke tiap function call. Untuk testing, di-export sebagai `_cache` supaya `beforeEach` bisa `_cache.clear()`.

Alternatif factory (`createConverter(cache)`) saya tolak karena overkill untuk scope project ini dan menambah surface area tanpa benefit nyata.

**2. `Promise.all` untuk dua API call.**

`fetchCryptoUsd` dan `fetchUsdToIdr` independen — di-fire paralel pakai `Promise.all`. Cache miss pertama: 2 round-trip → 1 wall-clock latency (~max(t1, t2), bukan t1+t2).

**3. `Math.round` di hasil akhir.**

IDR adalah currency tanpa desimal. Tanpa round, kombinasi `amount` float × `usdPrice` float × `idrRate` float bisa menghasilkan trailing decimal (mis. `8000000000.0000001`). Round di akhir bukan di tiap step — supaya tidak akumulasi error.

**4. Validasi `amount` SEBELUM `Promise.all`.**

Kalau `amount` invalid (NaN, negative, string), `convertToIdr` throw `InputError` tanpa fire API call sama sekali. Hemat quota CoinGecko & latency.

**5. Typed errors: `InputError` (code `INPUT`) vs `UpstreamError` (code `UPSTREAM`).**

Server map `code: 'INPUT'` → 400, lainnya → 502. Distinction penting karena:
- 400 = client harus fix request
- 502 = upstream API yang masalah, client harus retry / pakai endpoint lain

Regex-matching error message untuk classification (alternatif yang ditolak) brittle dan susah di-refactor.

**6. dotenv hanya di entry point.**

`require('dotenv').config()` hanya dipanggil di `3_crypto_to_idr_converter.js` (CLI) dan blok `require.main` di `server.js`. **Tidak di `converter.js` atau `cache.js`** — supaya saat di-import oleh test, tidak ada hidden side-effect membaca file `.env` developer. Library file cuma baca `process.env.X || default`.

**7. `nock.disableNetConnect()` di test setup.**

Kalau test accidentally hit network beneran (misal forgot to mock), nock akan throw loud error. Defense-in-depth: deterministic test guaranteed, plus catch bug "lupa mock" yang biasa kelupaan.

**8. HTML interface vanilla JS, no framework.**

`public/index.html` self-contained — fetch ke `/symbols` untuk populate dropdown (DRY: gak hardcode symbol list di HTML), `/convert` untuk konversi, format hasil pakai `Intl.NumberFormat('id-ID')` (mis. `Rp 8.000.000.000`). Total ~80 baris HTML+JS+CSS, no build step.

## Test Coverage

| File | Cover |
|---|---|
| `cache.test.js` | get/set within TTL, expiry, expired entry cleanup, clear, invalid TTL |
| `converter.test.js` | happy BTC/ETH, amount=0, Math.round, caching (2 call = 1 hit), per-symbol cache, unsupported symbol, missing symbol, 6 invalid amount variants, invalid CoinGecko response, invalid exchange response, CoinGecko 500, exchange network error |
| `server.test.js` | GET /symbols, POST happy, 400 input error (×2), 502 upstream, 400 broken JSON |

**Total: 30 tests** (6 cache + 18 converter + 6 server). Lihat output `npm test` untuk breakdown lengkap.

## Limitations

- Cache singleton: kalau spawn multiple Node process (mis. PM2 cluster), tiap process punya cache sendiri. Untuk production scale: ganti backend dengan Redis. Out of scope untuk technical test.
- Tidak ada rate limiting di endpoint server — CoinGecko free tier ~50 req/menit. Production butuh upstream rate limiter.
- Symbol mapping hardcoded — kalau butuh extend, edit `SYMBOL_MAP` di [converter.js](converter.js#L6).
